
import React, { useState, useCallback, useEffect } from 'react';
import { GameState, LessonContent } from './types';
import { LEVELS } from './constants';
import Platformer from './components/Platformer';
import LessonView from './components/LessonView';
import QuizView from './components/QuizView';
import RobinAvatar from './components/RobinAvatar';
import { fetchLessonForTopic } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [lesson, setLesson] = useState<LessonContent | null>(null);
  const [loading, setLoading] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const level = LEVELS[currentIdx];

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Erreur lors de l'activation du plein écran: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const handleFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const handleLevelComplete = useCallback(async () => {
    setLoading(true);
    setGameState(GameState.LESSON);
    try {
      const content = await fetchLessonForTopic(level.topic);
      setLesson(content);
    } catch {
      setGameState(GameState.MENU);
    } finally {
      setLoading(false);
    }
  }, [level]);

  const handleNext = () => {
    if (currentIdx < LEVELS.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setGameState(GameState.MENU);
    } else {
      setGameState(GameState.WIN);
    }
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-black font-sans overflow-hidden text-slate-100">
      
      {/* Bouton Plein Écran Flottant */}
      <button 
        onClick={toggleFullscreen}
        className="fixed top-6 right-6 z-50 p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:bg-white/10 hover:scale-110 active:scale-95 transition-all group"
        title={isFullscreen ? "Quitter le plein écran" : "Passer en plein écran"}
      >
        {isFullscreen ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-slate-400 group-hover:text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-slate-400 group-hover:text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>
          </svg>
        )}
      </button>

      {gameState === GameState.MENU && (
        <div className="max-w-md w-full bg-slate-900/40 p-10 rounded-[2.5rem] shadow-2xl text-center border border-white/10 backdrop-blur-xl animate-in fade-in zoom-in duration-500">
          <div className="animate-hero mb-6 flex justify-center">
            <RobinAvatar size="lg" />
          </div>
          <h1 className="text-4xl font-black mb-1 text-white tracking-tighter italic">DB-QUEST</h1>
          <p className="text-slate-500 text-[9px] font-bold uppercase tracking-[0.4em] mb-6">Simulation Académique Alpha-1</p>
          
          <div className="bg-black/40 p-5 rounded-2xl mb-6 text-left border border-white/5">
            <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></span>
              Briefing de Mission
            </div>
            <p className="text-slate-400 text-xs leading-relaxed italic">
              "Robin, l'archiviste d'élite, les structures de données mondiales s'effondrent sous l'effet de l'entropie. Votre mission est de pénétrer les 10 couches du Noyau de Connaissance. Traversez les plateformes de sécurité, apprenez les protocoles SQL et validez chaque module par un quiz de haute sécurité pour restaurer l'ordre numérique."
            </p>
          </div>

          <div className="bg-black/60 p-6 rounded-3xl mb-8 border border-white/5 shadow-inner">
             <div className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-2">Objectif Actuel</div>
             <div className="text-white font-bold text-base leading-tight">{level.topic}</div>
             <div className="mt-4 flex justify-center gap-1">
                {LEVELS.map((_, i) => (
                  <div key={i} className={`h-1 rounded-full transition-all duration-300 ${i === currentIdx ? 'w-6' : 'w-2 bg-white/10'}`} style={{ backgroundColor: i === currentIdx ? level.themeColor : '' }}></div>
                ))}
             </div>
          </div>
          
          <button onClick={() => setGameState(GameState.PLAYING)} 
                  className="w-full py-5 rounded-[1.5rem] text-white font-black uppercase text-xs tracking-[0.3em] transition-all hover:brightness-110 hover:scale-105 active:scale-95 shadow-2xl shadow-indigo-500/10"
                  style={{ backgroundColor: level.themeColor }}>
            Lancer la Simulation
          </button>
        </div>
      )}

      {gameState === GameState.PLAYING && (
        <Platformer level={level} onLevelComplete={handleLevelComplete} onGameOver={() => setGameState(GameState.GAMEOVER)} />
      )}

      {gameState === GameState.LESSON && (
        loading ? (
          <div className="flex flex-col items-center">
            <div className="animate-hero mb-8">
              <RobinAvatar size="md" />
            </div>
            <div className="text-[10px] font-black uppercase tracking-[0.5em] text-white animate-pulse">Synchronisation des Flux...</div>
          </div>
        ) : lesson && (
          <LessonView lesson={lesson} themeColor={level.themeColor} onNext={() => setGameState(GameState.QUIZ)} />
        )
      )}

      {gameState === GameState.QUIZ && lesson && (
        <QuizView questions={lesson.quiz} themeColor={level.themeColor} onPass={handleNext} />
      )}

      {gameState === GameState.GAMEOVER && (
        <div className="max-w-xs w-full bg-slate-950 p-10 rounded-[2.5rem] text-center shadow-2xl border border-red-500/20">
          <div className="text-5xl mb-6">🛑</div>
          <h2 className="text-xl font-black mb-6 uppercase text-white tracking-tighter">Échec de Connexion</h2>
          <button onClick={() => setGameState(GameState.PLAYING)} className="w-full py-5 bg-red-600/90 text-white rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-red-600 transition-colors">Réinitialiser</button>
        </div>
      )}

      {gameState === GameState.WIN && (
        <div className="max-w-md w-full bg-slate-950 p-12 rounded-[3rem] text-center shadow-2xl border border-emerald-500/20">
          <div className="animate-hero mb-8 flex justify-center">
            <RobinAvatar size="lg" />
          </div>
          <h1 className="text-3xl font-black mb-2 text-white uppercase tracking-tighter">Maître Archiviste</h1>
          <p className="text-slate-500 mb-10 text-sm leading-relaxed px-4">Toutes les structures de données sont désormais optimisées. L'Académie vous salue, Robin.</p>
          <button onClick={() => {setCurrentIdx(0); setGameState(GameState.MENU);}} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg shadow-emerald-500/20">Recommencer le Cycle</button>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.05); border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default App;
