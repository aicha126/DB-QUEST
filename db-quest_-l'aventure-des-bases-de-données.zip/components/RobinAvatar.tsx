
import React from 'react';

interface RobinAvatarProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const RobinAvatar: React.FC<RobinAvatarProps> = ({ className = "", size = 'md' }) => {
  // Ajustement des échelles pour réduire la présence visuelle globale
  const scale = size === 'sm' ? 'scale-[0.5]' : size === 'lg' ? 'scale-[0.9]' : 'scale-[0.7]';

  return (
    <div className={`relative ${scale} ${className} transition-transform duration-300 transform-gpu`}>
      <div className="relative w-24 h-36 flex flex-col items-center">
        
        {/* Cape Noire */}
        <div className="absolute top-14 w-20 h-16 bg-black rounded-b-md shadow-lg z-0"></div>

        {/* Cheveux Hérissés */}
        <div className="absolute -top-3 w-16 h-10 z-40 overflow-visible">
            <svg viewBox="0 0 100 50" className="w-full h-full fill-black">
                <path d="M10,50 L5,30 L25,45 L35,5 L50,40 L65,0 L75,45 L95,30 L90,50 Z" />
            </svg>
        </div>

        {/* Tête RECTANGULAIRE */}
        <div className="relative z-30 flex flex-col items-center">
          <div className="w-16 h-16 bg-[#fbd8c0] flex flex-col items-center relative overflow-hidden shadow-inner border-b border-black/10">
            {/* Masque Noir Rectangulaire */}
            <div className="w-full h-7 bg-black mt-3 flex justify-around items-center px-1">
              <div className="w-5 h-3.5 bg-white rounded-sm"></div>
              <div className="w-5 h-3.5 bg-white rounded-sm"></div>
            </div>
          </div>
          <div className="w-6 h-3 bg-black -mt-0.5"></div>
        </div>

        {/* Col Jaune */}
        <div className="w-18 h-3 bg-[#f7e316] z-20 -mt-0.5 flex justify-center items-start overflow-hidden">
            <div className="w-8 h-8 bg-black rotate-45 -mt-7"></div>
        </div>

        {/* Torse Rouge */}
        <div className="relative w-16 h-14 bg-[#d91e1e] z-10 flex items-center justify-between px-2 shadow-md">
          {/* 3 Barres Jaunes */}
          <div className="flex flex-col gap-1.5 ml-0.5">
            <div className="w-4 h-1 bg-[#f7e316]"></div>
            <div className="w-4 h-1 bg-[#f7e316]"></div>
            <div className="w-4 h-1 bg-[#f7e316]"></div>
          </div>

          {/* Badge R */}
          <div className="w-6 h-6 bg-[#f7e316] rounded-full flex items-center justify-center border-2 border-black/80 mr-0.5">
            <span className="text-[9px] font-black text-black">R</span>
          </div>

          {/* Manches Vertes */}
          <div className="absolute -left-3 top-0 w-3 h-8 bg-[#108c3a]"></div>
          <div className="absolute -right-3 top-0 w-3 h-8 bg-[#108c3a]"></div>
        </div>

        {/* Ceinture Jaune */}
        <div className="w-18 h-3.5 bg-[#f7e316] z-20 border-y border-black/10 flex justify-center items-center">
          <div className="w-6 h-full bg-[#e5cf10] border-x border-black/10"></div>
        </div>

        {/* Jambes Noires */}
        <div className="flex gap-1 z-0">
          <div className="flex flex-col items-center">
            <div className="w-7 h-8 bg-black"></div>
            <div className="w-8 h-3 bg-black rounded-t-sm"></div>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-7 h-8 bg-black"></div>
            <div className="w-8 h-3 bg-black rounded-t-sm"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RobinAvatar;
