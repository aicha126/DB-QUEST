
import React, { useState } from 'react';
import { QuizQuestion } from '../types';

interface QuizViewProps {
  questions: QuizQuestion[];
  themeColor: string;
  onPass: () => void;
}

const QuizView: React.FC<QuizViewProps> = ({ questions, themeColor, onPass }) => {
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [error, setError] = useState(false);
  const [done, setDone] = useState(false);

  const q = questions[idx];

  const handleValider = () => {
    if (selected === q.correctIndex) {
      if (idx < questions.length - 1) {
        setIdx(idx + 1);
        setSelected(null);
        setError(false);
      } else {
        setDone(true);
      }
    } else {
      setError(true);
    }
  };

  if (done) {
    return (
      <div className="max-w-sm w-full bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl text-center border border-emerald-500/30 animate-in zoom-in duration-300">
        <div className="text-6xl mb-6">✨</div>
        <h2 className="text-2xl font-black mb-2 text-white">CONNAISSANCES VALIDÉES</h2>
        <p className="text-slate-400 mb-8 text-sm leading-relaxed">Le module a été assimilé avec succès par Robin.</p>
        <button onClick={onPass} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg active:scale-95 transition-transform">Niveau Suivant</button>
      </div>
    );
  }

  return (
    <div className="max-w-xl w-full bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl border border-white/5 animate-in fade-in slide-in-from-bottom-6">
      <div className="flex justify-between items-center mb-6">
        <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">ÉVALUATION {idx + 1} / {questions.length}</div>
        <div className="h-1.5 w-32 bg-white/5 rounded-full overflow-hidden">
            <div className="h-full transition-all duration-500" style={{ backgroundColor: themeColor, width: `${((idx + 1) / questions.length) * 100}%` }}></div>
        </div>
      </div>
      
      <h2 className="text-2xl font-bold text-white mb-10 leading-snug tracking-tight">{q.question}</h2>

      <div className="space-y-3 mb-10">
        {q.options.map((opt, i) => (
          <button key={i} onClick={() => {setSelected(i); setError(false);}}
            className={`w-full p-5 text-left rounded-2xl border-2 transition-all flex items-center gap-5 ${
              selected === i ? 'border-white bg-white text-black' : 'border-white/5 hover:border-white/20 bg-black/20 text-slate-400'
            }`}>
            <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${selected === i ? 'bg-black text-white' : 'bg-white/10 text-white'}`}>
              {String.fromCharCode(65 + i)}
            </span>
            <span className="text-base font-semibold">{opt}</span>
          </button>
        ))}
      </div>

      {error && <div className="text-red-500 text-[11px] font-black uppercase tracking-widest text-center mb-6 animate-bounce">Accès refusé. Analysez à nouveau.</div>}

      <button disabled={selected === null} onClick={handleValider}
              className={`w-full py-5 rounded-2xl font-black uppercase text-xs tracking-[0.2em] transition-all shadow-xl ${
                selected === null ? 'opacity-20 bg-slate-700 cursor-not-allowed' : 'bg-white text-black hover:scale-[1.02] active:scale-95'
              }`}>
        Confirmer le Choix
      </button>
    </div>
  );
};

export default QuizView;
