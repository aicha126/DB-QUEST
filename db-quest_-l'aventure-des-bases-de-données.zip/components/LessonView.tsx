
import React, { useState } from 'react';
import { LessonContent } from '../types';
import RobinAvatar from './RobinAvatar';

interface LessonViewProps {
  lesson: LessonContent;
  onNext: () => void;
  themeColor: string;
}

const LessonView: React.FC<LessonViewProps> = ({ lesson, onNext, themeColor }) => {
  const [page, setPage] = useState(0);
  const section = lesson.sections[page];

  return (
    <div className="max-w-2xl w-full bg-slate-900 rounded-[2.5rem] shadow-2xl flex flex-col h-[600px] overflow-hidden border border-white/5 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <div className="p-8 border-b border-white/5 flex justify-between items-center bg-black/20">
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-tight">{lesson.title}</h2>
          <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-1">Extraction de données réussie</div>
        </div>
        <RobinAvatar size="sm" />
      </div>

      <div className="flex-1 p-10 overflow-y-auto custom-scrollbar">
        <div key={page} className="animate-in fade-in duration-300">
          <div className="flex items-center gap-4 mb-6">
            <span className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-lg" style={{ backgroundColor: themeColor }}>
              {page + 1}
            </span>
            <h3 className="text-xl font-bold text-white tracking-tight">{section.heading}</h3>
          </div>
          <p className="text-slate-400 leading-relaxed text-lg mb-8">{section.content}</p>
          {section.example && (
            <div className="bg-black/50 p-6 rounded-2xl font-mono text-sm text-indigo-300 border-l-4" style={{ borderLeftColor: themeColor }}>
              {section.example}
            </div>
          )}
        </div>
      </div>

      <div className="p-8 bg-black/40 border-t border-white/5 flex items-center justify-between">
        <div className="flex gap-2">
          {lesson.sections.map((_, i) => (
            <div key={i} className={`h-1.5 w-8 rounded-full transition-all duration-300 ${i === page ? 'bg-white' : 'bg-white/10'}`} />
          ))}
        </div>
        <div className="flex gap-3">
          {page > 0 && <button onClick={() => setPage(page-1)} className="px-6 py-2 text-slate-500 font-bold text-xs uppercase hover:text-white transition-colors">Précédent</button>}
          <button onClick={() => page < lesson.sections.length - 1 ? setPage(page+1) : onNext()} 
                  className="px-8 py-3 rounded-xl text-white font-black text-xs uppercase tracking-widest shadow-lg transition-transform active:scale-95"
                  style={{ backgroundColor: page < lesson.sections.length - 1 ? themeColor : '#059669' }}>
            {page < lesson.sections.length - 1 ? 'Continuer' : 'Lancer le Quiz 🎓'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LessonView;
