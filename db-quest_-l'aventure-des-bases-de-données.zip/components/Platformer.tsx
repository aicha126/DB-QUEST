
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerState, LevelConfig } from '../types';
import { GRAVITY, JUMP_FORCE, MOVE_SPEED } from '../constants';

interface PlatformerProps {
  level: LevelConfig;
  onLevelComplete: () => void;
  onGameOver: () => void;
}

const Platformer: React.FC<PlatformerProps> = ({ level, onLevelComplete, onGameOver }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [isMobile, setIsMobile] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') audioCtxRef.current.resume();
  };

  const LOGICAL_HEIGHT = 600;
  const LOGICAL_WIDTH = 800;
  
  const [player, setPlayer] = useState<PlayerState>({
    x: level.playerStart.x,
    y: level.playerStart.y,
    vx: 0,
    vy: 0,
    width: 30,
    height: 48,
    isJumping: false,
    jumpCount: 0,
  });

  const keys = useRef<{ [key: string]: boolean }>({});
  const lastJumpPress = useRef<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      setDimensions({ width: window.innerWidth, height: window.innerHeight });
      setIsMobile(window.matchMedia("(pointer: coarse)").matches);
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { initAudio(); keys.current[e.code] = true; };
    const handleKeyUp = (e: KeyboardEvent) => (keys.current[e.code] = false);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const update = useCallback(() => {
    setPlayer((p) => {
      let nx = p.x;
      let ny = p.y;
      let nvx = p.vx;
      let nvy = p.vy;
      let jumping = p.isJumping;
      let nJumpCount = p.jumpCount;

      if (keys.current['ArrowLeft'] || keys.current['KeyA']) nvx = -MOVE_SPEED;
      else if (keys.current['ArrowRight'] || keys.current['KeyD']) nvx = MOVE_SPEED;
      else nvx = 0;

      const jumpKeyPressed = keys.current['Space'] || keys.current['ArrowUp'] || keys.current['KeyW'];
      if (jumpKeyPressed && !lastJumpPress.current && nJumpCount < 2) {
        nvy = JUMP_FORCE;
        jumping = true;
        nJumpCount++;
      }
      lastJumpPress.current = jumpKeyPressed;

      nvy += GRAVITY;
      nx += nvx;
      ny += nvy;

      if (nx + p.width > level.goal.x && nx < level.goal.x + level.goal.w && ny + p.height > level.goal.y && ny < level.goal.y + level.goal.h) {
         onLevelComplete();
         return p;
      }

      let grounded = false;
      level.platforms.forEach((plat) => {
        if (nx < plat.x + plat.w && nx + p.width > plat.x && ny < plat.y + plat.h && ny + p.height > plat.y) {
          if (nvy >= 0 && p.y + p.height <= plat.y + 15) {
            ny = plat.y - p.height;
            nvy = 0;
            grounded = true;
          } 
          else if (nvy < 0 && p.y >= plat.y + plat.h - 15) {
            ny = plat.y + plat.h;
            nvy = 0;
          } 
          else if (nvx > 0) nx = plat.x - p.width;
          else if (nvx < 0) nx = plat.x + plat.w;
        }
      });

      if (grounded) { jumping = false; nJumpCount = 0; }
      if (nx < 0) nx = 0;
      if (nx > LOGICAL_WIDTH - p.width) nx = LOGICAL_WIDTH - p.width;
      if (ny > LOGICAL_HEIGHT + 100) {
        onGameOver();
        return { ...p, x: level.playerStart.x, y: level.playerStart.y, vx: 0, vy: 0, jumpCount: 0, isJumping: false };
      }

      return { ...p, x: nx, y: ny, vx: nvx, vy: nvy, isJumping: jumping, jumpCount: nJumpCount };
    });
  }, [level, onLevelComplete, onGameOver]);

  useEffect(() => {
    let animationId: number;
    const loop = () => { update(); animationId = requestAnimationFrame(loop); };
    animationId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationId);
  }, [update]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const scale = Math.min(dimensions.width / LOGICAL_WIDTH, dimensions.height / LOGICAL_HEIGHT);
    const offsetX = (dimensions.width - (LOGICAL_WIDTH * scale)) / 2;
    const offsetY = (dimensions.height - (LOGICAL_HEIGHT * scale)) / 2;

    ctx.setTransform(1, 0, 0, 1, 0, 0); 
    ctx.fillStyle = '#000000'; // FOND NOIR PUR
    ctx.fillRect(0, 0, dimensions.width, dimensions.height);

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);

    // Plateformes avec couleur de niveau
    level.platforms.forEach((p) => {
      ctx.fillStyle = level.themeColor;
      ctx.fillRect(p.x, p.y, p.w, p.h);
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.fillRect(p.x, p.y, p.w, 3);
    });

    // Objectif
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath(); ctx.arc(level.goal.x + 20, level.goal.y + 25, 20, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'white'; ctx.font = '24px serif'; ctx.textAlign = 'center';
    ctx.fillText('🎓', level.goal.x + 20, level.goal.y + 33);

    // DESSIN DE ROBIN (Identique à l'avatar)
    const r = player;
    ctx.save();
    ctx.translate(r.x, r.y);
    
    // Cape Noire
    ctx.fillStyle = '#111'; ctx.fillRect(2, 16, r.width - 4, 20);
    // Cheveux Hérissés
    ctx.fillStyle = '#000'; ctx.beginPath(); ctx.moveTo(4, 2); ctx.lineTo(0, -4); ctx.lineTo(8, 1); ctx.lineTo(15, -6); ctx.lineTo(22, 1); ctx.lineTo(30, -4); ctx.lineTo(26, 2); ctx.closePath(); ctx.fill();
    // Tête
    ctx.fillStyle = '#fbd8c0'; ctx.fillRect(4, 2, 22, 14);
    // Masque
    ctx.fillStyle = '#000'; ctx.fillRect(4, 6, 22, 6);
    ctx.fillStyle = 'white'; ctx.fillRect(7, 8, 4, 3); ctx.fillRect(19, 8, 4, 3);
    // Torse Rouge
    ctx.fillStyle = '#d91e1e'; ctx.fillRect(4, 16, 22, 14);
    // Manches Vertes
    ctx.fillStyle = '#108c3a'; ctx.fillRect(0, 16, 4, 8); ctx.fillRect(26, 16, 4, 8);
    // Ceinture Jaune
    ctx.fillStyle = '#f7e316'; ctx.fillRect(4, 30, 22, 3);
    // Jambes
    ctx.fillStyle = '#111'; ctx.fillRect(6, 33, 8, 10); ctx.fillRect(16, 33, 8, 10);
    ctx.restore();

    ctx.restore();

    // HUD Dark Mode
    ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
    ctx.fillRect(0, 0, dimensions.width, 70);
    ctx.fillStyle = level.themeColor;
    ctx.fillRect(0, 68, dimensions.width, 2);

    ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = 'bold 10px sans-serif'; ctx.fillText(`MODULE #${level.id}`, 30, 30);
    ctx.fillStyle = 'white'; ctx.font = 'bold 22px sans-serif'; ctx.fillText(level.topic.toUpperCase(), 30, 55);

  }, [player, level, dimensions]);

  return (
    <div className="fixed inset-0 w-screen h-screen bg-black overflow-hidden touch-none">
      <canvas ref={canvasRef} width={dimensions.width} height={dimensions.height} />
      {isMobile && (
        <div className="absolute inset-0 pointer-events-none p-10 flex flex-col justify-end">
          <div className="flex justify-between pointer-events-auto">
            <div className="flex gap-4">
              <button onPointerDown={() => keys.current['ArrowLeft'] = true} onPointerUp={() => keys.current['ArrowLeft'] = false} className="w-16 h-16 bg-white/10 rounded-full text-white text-2xl border border-white/20">◀</button>
              <button onPointerDown={() => keys.current['ArrowRight'] = true} onPointerUp={() => keys.current['ArrowRight'] = false} className="w-16 h-16 bg-white/10 rounded-full text-white text-2xl border border-white/20">▶</button>
            </div>
            <button onPointerDown={() => keys.current['Space'] = true} onPointerUp={() => keys.current['Space'] = false} className="w-20 h-20 bg-indigo-600 text-white rounded-full font-bold border-4 border-indigo-400">JUMP</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Platformer;
