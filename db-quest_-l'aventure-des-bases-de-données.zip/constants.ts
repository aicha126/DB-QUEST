
import { LevelConfig } from './types';

export const CANVAS_WIDTH = 800;
export const CANVAS_HEIGHT = 600;
export const GRAVITY = 0.5;
export const JUMP_FORCE = -10;
export const MOVE_SPEED = 7; 

export const LEVELS: LevelConfig[] = [
  {
    id: 1,
    topic: "Introduction aux Bases de Données",
    themeColor: "#6366f1",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 800, h: 50 },
      { x: 150, y: 450, w: 100, h: 20 },
      { x: 300, y: 350, w: 100, h: 20 },
      { x: 450, y: 250, w: 100, h: 20 },
      { x: 600, y: 150, w: 150, h: 20 },
    ],
    goal: { x: 700, y: 100, w: 40, h: 50 }
  },
  {
    id: 2,
    topic: "Tables, Colonnes et Lignes",
    themeColor: "#3b82f6",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 200, h: 50 },
      { x: 250, y: 500, w: 100, h: 20 },
      { x: 400, y: 450, w: 100, h: 20 },
      { x: 550, y: 400, w: 100, h: 20 },
      { x: 700, y: 350, w: 100, h: 20 },
      { x: 500, y: 250, w: 100, h: 20 },
      { x: 300, y: 200, w: 100, h: 20 },
      { x: 100, y: 150, w: 150, h: 20 },
    ],
    goal: { x: 150, y: 100, w: 40, h: 50 }
  },
  {
    id: 3,
    topic: "Clés Primaires et Etrangères",
    themeColor: "#8b5cf6",
    playerStart: { x: 50, y: 100 },
    platforms: [
      { x: 0, y: 150, w: 150, h: 20 },
      { x: 200, y: 250, w: 100, h: 20 },
      { x: 50, y: 350, w: 100, h: 20 },
      { x: 250, y: 450, w: 150, h: 20 },
      { x: 450, y: 350, w: 100, h: 20 },
      { x: 650, y: 250, w: 100, h: 20 },
      { x: 550, y: 150, w: 200, h: 20 },
    ],
    goal: { x: 700, y: 100, w: 40, h: 50 }
  },
  {
    id: 4,
    topic: "MCD : Entités et Associations",
    themeColor: "#ec4899",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 150, h: 50 },
      { x: 200, y: 500, w: 100, h: 20 },
      { x: 350, y: 400, w: 120, h: 20 },
      { x: 500, y: 300, w: 100, h: 20 },
      { x: 200, y: 250, w: 100, h: 20 },
      { x: 400, y: 150, w: 200, h: 20 },
      { x: 700, y: 250, w: 80, h: 20 },
    ],
    goal: { x: 720, y: 200, w: 40, h: 50 }
  },
  {
    id: 5,
    topic: "MLD : Tables et Intégrité",
    themeColor: "#f43f5e",
    playerStart: { x: 100, y: 100 },
    platforms: [
      { x: 50, y: 150, w: 200, h: 20 },
      { x: 300, y: 200, w: 150, h: 20 },
      { x: 500, y: 250, w: 150, h: 20 },
      { x: 700, y: 300, w: 100, h: 20 },
      { x: 500, y: 400, w: 150, h: 20 },
      { x: 300, y: 500, w: 150, h: 20 },
      { x: 100, y: 400, w: 150, h: 20 },
      { x: 0, y: 300, w: 100, h: 20 },
    ],
    goal: { x: 20, y: 250, w: 40, h: 50 }
  },
  {
    id: 6,
    topic: "MPD : Index et Optimisation",
    themeColor: "#0ea5e9",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 100, h: 50 },
      { x: 150, y: 450, w: 60, h: 20 },
      { x: 300, y: 450, w: 60, h: 20 },
      { x: 450, y: 450, w: 60, h: 20 },
      { x: 600, y: 350, w: 60, h: 20 },
      { x: 450, y: 250, w: 60, h: 20 },
      { x: 300, y: 150, w: 60, h: 20 },
      { x: 50, y: 100, w: 150, h: 20 },
    ],
    goal: { x: 100, y: 50, w: 40, h: 50 }
  },
  {
    id: 7,
    topic: "Introduction aux KPIs",
    themeColor: "#10b981",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 200, h: 50 },
      { x: 250, y: 450, w: 150, h: 20 },
      { x: 500, y: 350, w: 150, h: 20 },
      { x: 650, y: 250, w: 120, h: 20 },
      { x: 500, y: 150, w: 150, h: 20 },
      { x: 250, y: 100, w: 200, h: 20 },
    ],
    goal: { x: 300, y: 50, w: 40, h: 50 }
  },
  {
    id: 8,
    topic: "KPIs : Collecte et Agrégation",
    themeColor: "#f59e0b",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 250, h: 50 },
      { x: 300, y: 460, w: 120, h: 20 },
      { x: 480, y: 380, w: 120, h: 20 },
      { x: 620, y: 300, w: 120, h: 20 },
      { x: 450, y: 230, w: 120, h: 20 },
      { x: 220, y: 170, w: 180, h: 20 },
    ],
    goal: { x: 300, y: 100, w: 40, h: 50 }
  },
  {
    id: 9,
    topic: "KPIs : Du SQL au Dashboard",
    themeColor: "#ef4444",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 150, h: 20 },
      { x: 200, y: 450, w: 150, h: 20 },
      { x: 400, y: 350, w: 150, h: 20 },
      { x: 600, y: 250, w: 150, h: 20 },
      { x: 400, y: 150, w: 150, h: 20 },
      { x: 200, y: 150, w: 100, h: 20 },
    ],
    goal: { x: 220, y: 100, w: 40, h: 50 }
  },
  {
    id: 10,
    topic: "Transactions (ACID) et Synthèse",
    themeColor: "#64748b",
    playerStart: { x: 50, y: 500 },
    platforms: [
      { x: 0, y: 550, w: 800, h: 50 },
      { x: 700, y: 450, w: 100, h: 20 },
      { x: 500, y: 350, w: 100, h: 20 },
      { x: 300, y: 250, w: 100, h: 20 },
      { x: 100, y: 150, w: 150, h: 20 },
    ],
    goal: { x: 150, y: 100, w: 40, h: 50 }
  }
];
