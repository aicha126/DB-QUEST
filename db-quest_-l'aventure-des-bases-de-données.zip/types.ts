
export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  LESSON = 'LESSON',
  QUIZ = 'QUIZ',
  GAMEOVER = 'GAMEOVER',
  WIN = 'WIN'
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
}

export interface LessonContent {
  title: string;
  sections: {
    heading: string;
    content: string;
    example?: string;
  }[];
  quiz: QuizQuestion[];
}

export interface LevelConfig {
  id: number;
  topic: string;
  themeColor: string; // Nouvelle propriété pour varier le visuel
  platforms: { x: number; y: number; w: number; h: number }[];
  goal: { x: number; y: number; w: number; h: number };
  playerStart: { x: number; y: number };
}

export interface PlayerState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  isJumping: boolean;
  jumpCount: number;
}
