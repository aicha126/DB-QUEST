
import { GoogleGenAI, Type } from "@google/genai";
import { LessonContent } from "../types";

const FALLBACK_LESSONS: Record<string, LessonContent> = {
  "Introduction aux Bases de Données": {
    title: "Le Fondement de l'Architecture de Données",
    sections: [
      { 
        heading: "L'Essence de la Persistance", 
        content: "Une base de données n'est pas un simple espace de stockage passif ; c'est un système complexe conçu pour garantir que la donnée survit aux pannes matérielles, reste cohérente et soit accessible par des milliers d'utilisateurs simultanément sans conflit. Contrairement aux fichiers plats, elle utilise des structures sophistiquées pour indexer l'information. Imaginez une bibliothèque magique où chaque livre se range instantanément à sa place exacte et où personne ne peut déchirer ou modifier une page sans autorisation. C'est cette sécurité et cette organisation qui font d'elle le coeur de toute application moderne.", 
        example: "SGBD célèbres : PostgreSQL (réputé pour sa robustesse), MongoDB (pour la flexibilité documentaire), SQLite (intégré partout)." 
      },
      { 
        heading: "L'Arbitre : Le SGBD", 
        content: "Le Système de Gestion de Base de Données (SGBD) est le logiciel qui pilote la base. Il agit comme une couche d'intelligence indispensable entre vos fichiers physiques stockés sur le disque dur et vos applications. Il gère l'authentification des utilisateurs, optimise les recherches complexes et assure que deux personnes ne modifient pas la même information au même instant, un concept nommé gestion de la concurrence. Sans lui, les données finiraient par se mélanger et se corrompre, rendant le système inutilisable pour une entreprise.", 
        example: "Le SGBD empêche deux clients d'acheter le dernier billet d'avion exactement au même millième de seconde." 
      },
      { 
        heading: "Le Standard Universel : SQL", 
        content: "Le SQL (Structured Query Language) est la langue universelle utilisée par les ingénieurs pour dialoguer avec les bases de données. C'est un langage dit 'déclaratif' : cela signifie que vous ne dictez pas à l'ordinateur les étapes techniques de recherche, mais vous lui décrivez simplement le résultat que vous souhaitez obtenir. Cette abstraction puissante permet de manipuler des téraoctets de données avec quelques lignes de code élégantes. Apprendre le SQL, c'est acquérir la clé pour extraire de la valeur de n'importe quel entrepôt de données dans le monde.", 
        example: "Syntaxe type : SELECT nom, email FROM utilisateurs WHERE pays = 'France' ORDER BY date_creation DESC;" 
      }
    ],
    quiz: [
      { question: "Quel est le rôle principal d'un SGBD ?", options: ["Éditer des vidéos", "Interdire l'accès à internet", "Compiler du code binaire", "Gérer l'accès, l'intégrité et la sécurité des données"], correctIndex: 3 },
      { question: "Qui est le créateur du modèle relationnel ?", options: ["Steve Jobs", "Edgar F. Codd", "Ada Lovelace", "James Gosling"], correctIndex: 1 },
      { question: "Le SQL est un langage de quel type ?", options: ["Impératif", "Visuel", "Déclaratif", "De bas niveau"], correctIndex: 2 },
      { question: "Quelle est la différence majeure avec un fichier Excel ?", options: ["La gestion robuste des accès multi-utilisateurs", "Le nombre de couleurs disponibles", "La possibilité de faire des additions", "Le prix de la licence"], correctIndex: 0 },
      { question: "Que signifie le 'Q' dans l'acronyme SQL ?", options: ["Quality", "Quick", "Query", "Quantum"], correctIndex: 2 }
    ]
  },
  "Tables, Colonnes et Lignes": {
    title: "Anatomie d'une Table Relationnelle",
    sections: [
      { 
        heading: "La Table : Le Sujet Unique", 
        content: "Dans le monde relationnel, chaque table doit être dédiée à un sujet métier unique et indivisible. On appelle cela l'atomicité conceptuelle. Mélanger des informations sur les produits et sur les factures dans une même table créerait un chaos informationnel et des redondances inutiles. Une table bien conçue est comme un classeur parfaitement étiqueté : elle ne contient que ce qui concerne son étiquette. Cette séparation stricte permet une maintenance aisée et une évolution rapide du système d'information.", 
        example: "Tables recommandées : 'Utilisateurs', 'Commandes', 'Lignes_De_Commande', 'Produits'." 
      },
      { 
        heading: "Colonnes (Attributs) et Typage Fort", 
        content: "Chaque colonne définit une caractéristique précise de l'objet stocké. Le typage est un aspect critique de la performance : un 'Age' doit être un petit entier (TINYINT), un 'Prix' un nombre décimal précis (DECIMAL), et un 'Nom' une chaîne de caractères de taille variable (VARCHAR). En définissant ces types, vous aidez le moteur de la base de données à optimiser l'espace sur le disque et à prévenir les erreurs de saisie stupides, comme tenter d'enregistrer une date dans une colonne de prix.", 
        example: "VARCHAR(100) pour un nom, INT pour un compteur, DATETIME pour un horodatage." 
      },
      { 
        heading: "Lignes (Tuples) et Identité", 
        content: "Une ligne, techniquement appelée 'tuple', représente une instance concrète et unique de votre sujet. Si la table est 'Voiture', une ligne est UNE voiture spécifique avec sa couleur et sa plaque. Pour que le système fonctionne, chaque ligne doit idéalement être identifiable de manière unique. La collection totale de ces lignes forme l'ensemble de votre base de données métier, et leur structure uniforme permet des recherches de masse extrêmement rapides grâce aux algorithmes du SGBD.", 
        example: "Une ligne = L'utilisateur 'Robin', inscrit le 12/05, avec l'ID unique 450." 
      }
    ],
    quiz: [
      { question: "Quel type de donnée est idéal pour un montant financier ?", options: ["DECIMAL", "BOOLEAN", "TEXT", "INTEGER"], correctIndex: 0 },
      { question: "Le terme technique pour une ligne de donnée est :", options: ["Un champ", "Un attribut", "Un index", "Un tuple"], correctIndex: 3 },
      { question: "Que définit le schéma d'une table ?", options: ["Le mot de passe admin", "La liste des colonnes et leurs types", "L'adresse du serveur", "Le nombre d'utilisateurs connectés"], correctIndex: 1 },
      { question: "Le type VARCHAR sert à stocker :", options: ["Des dates", "Des images", "Du texte de longueur variable", "Des nombres à virgule"], correctIndex: 2 },
      { question: "Un attribut correspond visuellement à :", options: ["Une ligne", "Une colonne", "La table entière", "Une cellule vide"], correctIndex: 1 }
    ]
  },
  "Clés Primaires et Etrangères": {
    title: "Liens et Intégrité Référentielle",
    sections: [
      { 
        heading: "La Clé Primaire (PK) : L'ADN de la Ligne", 
        content: "La Clé Primaire (Primary Key) est l'identifiant unique et obligatoire de chaque ligne. Elle ne peut jamais être nulle et ne peut jamais exister en double dans la même table. Elle garantit que chaque information peut être retrouvée sans aucune ambiguïté. C'est l'ancre sur laquelle reposent toutes les relations de votre base de données. Sans elle, il serait impossible de modifier ou de supprimer un enregistrement spécifique sans risquer d'affecter accidentellement ses voisins.", 
        example: "Un numéro d'étudiant, un code barre, ou un UUID (identifiant universel unique)." 
      },
      { 
        heading: "La Clé Étrangère (FK) : Le Pont", 
        content: "La Clé Étrangère (Foreign Key) est une colonne dans une table qui contient la valeur de la clé primaire d'une autre table. C'est ce mécanisme simple mais génial qui permet de créer des relations entre les objets. Par exemple, une table 'Commandes' aura une colonne 'id_client' qui pointe vers la table 'Clients'. Grâce à cela, on évite de réécrire tout le nom et l'adresse du client pour chaque commande, ce qui économise de l'espace et évite les erreurs de frappe.", 
        example: "FK commande.client_id -> PK client.id. On parle de relation parent-enfant." 
      },
      { 
        heading: "L'Intégrité Référentielle", 
        content: "C'est un ensemble de règles automatiques gérées par le SGBD pour protéger vos données contre les erreurs humaines. Par exemple, si vous essayez de supprimer un client qui a encore des commandes actives, le SGBD refusera l'opération. Cela empêche de créer des données 'orphelines' (une commande dont on ne sait plus qui est le client). C'est ce qui différencie une base de données professionnelle d'un simple tableau de données où tout peut être cassé en un clic.", 
        example: "Erreur SQL : Viol de contrainte de clé étrangère (on ne peut pas supprimer le parent)." 
      }
    ],
    quiz: [
      { question: "Une clé primaire peut-elle contenir des valeurs en double ?", options: ["Oui, si la table est petite", "Non, elle doit être absolument unique", "Seulement le dimanche", "Oui, sur certaines versions de SQL"], correctIndex: 1 },
      { question: "À quoi sert une clé étrangère ?", options: ["À trier les données", "À crypter le contenu", "À lier deux tables de manière cohérente", "À masquer les colonnes"], correctIndex: 2 },
      { question: "Que signifie PK ?", options: ["Primary Key", "Public Key", "Private Key", "Password Key"], correctIndex: 0 },
      { question: "L'intégrité référentielle empêche principalement :", options: ["Le piratage", "La lenteur du serveur", "Les fautes d'orthographe", "Les données orphelines et incohérentes"], correctIndex: 3 },
      { question: "Peut-on avoir plusieurs clés étrangères dans une table ?", options: ["Seulement deux", "Autant que nécessaire pour les liens", "Aucune", "Une seule"], correctIndex: 1 }
    ]
  },
  "MCD : Entités et Associations": {
    title: "Conception Conceptuelle (Méthode Merise)",
    sections: [
      { 
        heading: "L'Étape de l'Architecte", 
        content: "Le Modèle Conceptuel de Données (MCD) est la phase où l'on dessine l'intelligence du système avant de coder. On ignore totalement la technique (SGBD, serveurs) pour se concentrer uniquement sur les besoins du métier. On identifie les Entités (les objets du monde réel comme 'Avion' ou 'Passager') et les Associations (les verbes qui les lient comme 'Voyage_Dans'). C'est ici que l'on décide si un système sera capable de gérer les besoins futurs de l'entreprise ou s'il sera obsolète dès le premier jour.", 
        example: "Entités : Livre, Auteur. Association : Ecrit_Par." 
      },
      { 
        heading: "Les Cardinalités (0,N, 1,1...)", 
        content: "Les cardinalités sont les chiffres magiques du MCD. Elles décrivent combien de fois une entité peut participer à une association. '1,N' signifie qu'un client peut passer d'une à plusieurs commandes. '1,1' signifie qu'une commande appartient à un et un seul client. Ces règles dictent littéralement comment les tables seront construites plus tard. Une erreur de cardinalité au début du projet peut coûter des milliers d'euros car elle fausse toute la logique de stockage des données.", 
        example: "Cardinalité (0,1) : une voiture peut avoir au maximum un conducteur (ou aucun)." 
      },
      { 
        heading: "Attributs et Identifiants", 
        content: "Chaque entité possède des propriétés appelées attributs. L'attribut le plus important est l'identifiant (souvent souligné dans le schéma). Cet identifiant deviendra plus tard la fameuse Clé Primaire. Le but est de capturer toute l'information nécessaire sans en oublier. C'est une étape de dialogue intense entre les développeurs et les experts métiers pour s'assurer que rien n'est laissé au hasard.", 
        example: "Entité 'Produit' : [Référence (Identifiant), Prix, Stock, Couleur]." 
      }
    ],
    quiz: [
      { question: "Dans un MCD, une Entité est représentée par :", options: ["Un losange", "Un cercle", "Un rectangle", "Une flèche"], correctIndex: 2 },
      { question: "Que signifie la cardinalité (1,N) ?", options: ["Exactement 1", "Zéro ou 1", "De 1 à plusieurs", "Zéro"], correctIndex: 2 },
      { question: "Le symbole de l'association est :", options: ["Le rectangle", "Le cercle", "L'étoile", "Le losange"], correctIndex: 3 },
      { question: "Le but du MCD est de :", options: ["Calculer les prix", "Modéliser la logique métier sans technique", "Écrire le code Java", "Acheter des serveurs"], correctIndex: 1 },
      { question: "L'identifiant d'une entité deviendra :", options: ["Une colonne de texte", "Un fichier image", "La clé primaire", "Une vue SQL"], correctIndex: 2 }
    ]
  },
  "MLD : Tables et Intégrité": {
    title: "Le Modèle Logique de Données",
    sections: [
      { 
        heading: "La Traduction Technique", 
        content: "Le MLD est la traduction du dessin (MCD) en une structure de tables concrètes. On applique des règles strictes : les entités deviennent des tables, les associations se transforment soit en colonnes (clés étrangères), soit en nouvelles tables si la relation est complexe. C'est le moment où le concept abstrait rencontre la réalité du SQL. Cette étape permet de vérifier que tout ce qui a été imaginé est réellement réalisable techniquement avec un SGBD relationnel classique.", 
        example: "Relation N,N (Plusieurs à Plusieurs) -> Création d'une table de jointure." 
      },
      { 
        heading: "L'Art de la Normalisation", 
        content: "La normalisation (1NF, 2NF, 3NF) est un processus mathématique pour nettoyer votre base. Le but est de supprimer toute redondance. Si vous écrivez l'adresse d'un fournisseur dans chaque fiche produit, c'est une erreur de conception. Il faut isoler l'adresse dans une table 'Fournisseurs' et ne mettre que l'ID dans la table 'Produits'. Une base bien normalisée est légère, rapide et ne souffre jamais d'incohérences lors des mises à jour massives de données.", 
        example: "3NF : Ne pas stocker de données calculables ou dépendantes d'un autre champ non-clé." 
      },
      { 
        heading: "Contraintes de Domaine", 
        content: "Au niveau logique, on définit aussi les règles de validité. 'NOT NULL' rend un champ obligatoire. 'CHECK' permet de vérifier une valeur (ex: le prix doit être supérieur à 0). 'UNIQUE' garantit qu'on ne peut pas avoir deux fois le même email. Ces contraintes sont les gardiens de votre temple de données : elles empêchent les applications de mauvaise qualité d'envoyer des données corrompues dans votre système propre.", 
        example: "Contrainte : CHECK (age >= 18) pour un site de vote." 
      }
    ],
    quiz: [
      { question: "Une association de type N,N (plusieurs à plusieurs) devient :", options: ["Une colonne de texte", "Rien du tout", "Une clé primaire composée", "Une table de jointure intermédiaire"], correctIndex: 3 },
      { question: "Quel est le but principal de la normalisation ?", options: ["Réduire la redondance et les anomalies", "Ajouter des couleurs aux tables", "Ralentir les recherches", "Augmenter la taille des fichiers"], correctIndex: 0 },
      { question: "Que signifie la contrainte NOT NULL ?", options: ["La valeur doit être zéro", "Le champ ne peut pas être vide", "Le champ est optionnel", "La valeur est cryptée"], correctIndex: 1 },
      { question: "La règle 1NF impose que :", options: ["Les données soient bleues", "Chaque cellule soit atomique", "La table soit vide", "Le serveur soit puissant"], correctIndex: 1 },
      { question: "Le MLD introduit la notion de :", options: ["Clé étrangère", "Logiciel de dessin", "Prix de vente", "Vitesse CPU"], correctIndex: 0 }
    ]
  },
  "MPD : Index et Optimisation": {
    title: "Performance Physique et Indexation",
    sections: [
      { 
        heading: "L'Index : La Table des Matières", 
        content: "Sans index, pour trouver un utilisateur parmi 10 millions, le SGBD doit lire chaque ligne du disque dur une par une (Full Table Scan). C'est extrêmement lent. Un index crée une structure de recherche (souvent un B-Tree) qui permet au moteur de trouver la bonne ligne en seulement quelques micro-secondes. C'est l'équivalent de l'index à la fin d'un livre épais : au lieu de tout lire, vous allez directement à la page qui vous intéresse.", 
        example: "Index sur la colonne 'Email' pour une connexion instantanée." 
      },
      { 
        heading: "Le Coût Caché des Index", 
        content: "Attention : les index ne sont pas gratuits ! Chaque index prend de la place sur le disque et, surtout, ralentit les opérations d'écriture (INSERT, UPDATE). Pourquoi ? Parce qu'à chaque fois que vous ajoutez un client, le SGBD doit aussi mettre à jour tous ses index. Un bon ingénieur ne met pas des index partout, il choisit stratégiquement les colonnes les plus utilisées dans les recherches pour équilibrer vitesse de lecture et vitesse d'écriture.", 
        example: "Trop d'index = Écritures lentes. Pas assez d'index = Lectures interminables." 
      },
      { 
        heading: "Plan d'Exécution et Statistiques", 
        content: "Le SGBD possède un 'Optimiseur' qui analyse votre requête SQL avant de l'exécuter. Il regarde les index disponibles et les statistiques de la table pour décider du chemin le plus rapide. Parfois, il peut décider de ne pas utiliser d'index s'il juge que la table est trop petite. En utilisant la commande EXPLAIN, vous pouvez voir dans la tête du SGBD et comprendre pourquoi votre site est lent ou rapide. C'est le sommet de l'expertise en bases de données.", 
        example: "Utilisation de EXPLAIN SELECT... pour déboguer une lenteur." 
      }
    ],
    quiz: [
      { question: "Quel est l'avantage principal d'un index ?", options: ["Il réduit la sécurité", "Il accélère les lectures SELECT", "Il augmente la RAM", "Il supprime les virus"], correctIndex: 1 },
      { question: "Quel est l'inconvénient majeur des index ?", options: ["Ils ralentissent les INSERT", "Ils changent la langue", "Ils sont illisibles", "Ils coûtent cher"], correctIndex: 0 },
      { question: "Quelle commande permet de voir comment SQL traite une requête ?", options: ["DEBUG", "SHOW", "INFO", "EXPLAIN"], correctIndex: 3 },
      { question: "Une recherche sans index s'appelle :", options: ["Une vue rapide", "Un index caché", "Un Full Table Scan", "Un scan de sécurité"], correctIndex: 2 },
      { question: "La structure de données la plus courante pour un index est :", options: ["Une liste simple", "Une pile", "Une file", "Un B-Tree"], correctIndex: 3 }
    ]
  },
  "Introduction aux KPIs": {
    title: "La Donnée au Service de la Décision",
    sections: [
      { 
        heading: "Qu'est-ce qu'un KPI ?", 
        content: "Un KPI (Key Performance Indicator) est un indicateur chiffré qui permet de mesurer si une entreprise se rapproche de ses objectifs. Ce n'est plus de la donnée brute, c'est de l'information stratégique. Par exemple, le 'Chiffre d'Affaires' est une donnée, mais le 'Taux de Croissance du Chiffre d'Affaires' est un KPI car il indique une tendance et permet de prendre des décisions. C'est le passage de l'informatique pure à l'intelligence d'affaires (Business Intelligence).", 
        example: "Exemples : Taux de conversion, Panier moyen, Taux d'attrition (churn)." 
      },
      { 
        heading: "OLTP vs OLAP", 
        content: "Il existe deux mondes : l'OLTP (OnLine Transaction Processing) qui gère les clics rapides sur un site web, et l'OLAP (OnLine Analytical Processing) qui est une base de données séparée, optimisée pour l'analyse. On ne fait jamais de gros calculs de KPIs sur la base de production car cela ralentirait les clients. On copie les données dans un 'Data Warehouse' (entrepôt) où l'on peut calculer des statistiques sur des années sans gêner personne.", 
        example: "OLTP = Caisse de magasin ; OLAP = Rapport annuel du PDG." 
      },
      { 
        heading: "La Méthode SMART pour les KPIs", 
        content: "Un KPI inutile est une perte de temps. Pour être efficace, il doit suivre la méthode SMART : Spécifique (clair), Mesurable (chiffré), Atteignable (réaliste), Réaliste (pertinent) et Temporel (limité dans le temps). Un KPI comme 'Vendre plus' est mauvais. Un KPI comme 'Augmenter de 15% le nombre d'abonnés d'ici juin' est excellent car il est précis et permet de juger le succès ou l'échec de manière indiscutable.", 
        example: "S : Ventes, M : +10%, A : Possible, R : Utile, T : En 3 mois." 
      }
    ],
    quiz: [
      { question: "Que signifie l'acronyme KPI ?", options: ["Known Private Interface", "Key Performance Indicator", "Keep Private Information", "Kernel Process Intro"], correctIndex: 1 },
      { question: "Le système OLAP est optimisé pour :", options: ["Le jeu vidéo", "L'analyse de données massives", "Les micro-transactions", "L'envoi d'emails"], correctIndex: 1 },
      { question: "Le 'S' de SMART signifie :", options: ["Sérieux", "Simple", "Stable", "Spécifique"], correctIndex: 3 },
      { question: "Où calcule-t-on généralement les KPIs stratégiques ?", options: ["Dans la RAM", "Sur le PC du client", "Dans un Data Warehouse", "Sur une clé USB"], correctIndex: 2 },
      { question: "Un bon KPI doit être :", options: ["Vague", "Secret", "Mesurable", "Le plus grand possible"], correctIndex: 2 }
    ]
  },
  "KPIs : Collecte et Agrégation": {
    title: "SQL Avancé pour l'Analyse",
    sections: [
      { 
        heading: "Les Fonctions d'Agrégation", 
        content: "Pour transformer des millions de lignes en KPIs, SQL utilise des fonctions d'agrégation. SUM fait la somme, AVG calcule la moyenne, COUNT compte le nombre d'éléments, MIN et MAX trouvent les extrêmes. Ces fonctions sont les briques de base de tout rapport analytique. Elles permettent de compresser une montagne de données en un seul chiffre qui a du sens pour un décideur humain.", 
        example: "SELECT AVG(prix_commande) FROM ventes WHERE date = '2023-01-01';" 
      },
      { 
        heading: "GROUP BY : La Segmentation", 
        content: "Le GROUP BY est l'une des clauses les plus puissantes de SQL. Elle permet de découper vos calculs par segments. Au lieu de voir le total des ventes globales, vous pouvez voir le total PAR pays, PAR catégorie de produit ou PAR vendeur. C'est cette segmentation qui permet d'identifier précisément où l'entreprise réussit et où elle échoue. Un bon analyste passe 80% de son temps à 'grouper' les données pour trouver des pépites d'information.", 
        example: "SELECT pays, COUNT(*) FROM clients GROUP BY pays;" 
      },
      { 
        heading: "Le Filtrage HAVING", 
        content: "Il y a souvent une confusion entre WHERE et HAVING. WHERE filtre les lignes INDIVIDUELLES avant le calcul. HAVING filtre les GROUPES après le calcul. Par exemple, si vous voulez trouver les catégories de produits qui ont généré PLUS de 10 000€ de chiffre d'affaires, vous DEVEZ utiliser HAVING. C'est le filtre de précision ultime pour isoler les segments de marché les plus performants dans vos rapports financiers.", 
        example: "HAVING SUM(montant) > 10000;" 
      }
    ],
    quiz: [
      { question: "Quelle fonction SQL calcule la moyenne ?", options: ["MEAN", "SUM", "AVG", "TOTAL"], correctIndex: 2 },
      { question: "À quoi sert la clause GROUP BY ?", options: ["À trier", "À segmenter les calculs", "À supprimer", "À cacher"], correctIndex: 1 },
      { question: "Quelle est la différence entre WHERE et HAVING ?", options: ["Aucune", "WHERE filtre avant calcul, HAVING après", "HAVING est plus rapide", "WHERE est textuel"], correctIndex: 1 },
      { question: "Pour compter les lignes, on utilise :", options: ["ADD", "COUNT", "SUM", "LIST"], correctIndex: 1 },
      { question: "Peut-on grouper par plusieurs colonnes ?", options: ["Seulement deux", "Non", "Oui (ex: pays ET ville)", "Interdit"], correctIndex: 2 }
    ]
  },
  "KPIs : Du SQL au Dashboard": {
    title: "Visualisation et Communication",
    sections: [
      { 
        heading: "La Data Visualization (DataViz)", 
        content: "La donnée est inutile si elle n'est pas comprise. La DataViz est l'art de transformer des tableaux SQL arides en graphiques parlants. Un cerveau humain traite une image 60 000 fois plus vite qu'un texte. Un bon dashboard doit être conçu pour raconter une histoire claire sans que l'utilisateur n'ait besoin de poser de questions. C'est la vitrine finale de tout votre travail d'ingénieur de données, là où la valeur devient visible pour les chefs d'entreprise.", 
        example: "Outils leaders : Tableau Software, Power BI, Grafana." 
      },
      { 
        heading: "Choisir le Bon Graphique", 
        content: "Chaque donnée a son graphique idéal. Une COURBE (Line Chart) est parfaite pour montrer une évolution dans le temps. Un HISTOGRAMME (Bar Chart) est idéal pour comparer des catégories entre elles. Un CAMEMBERT (Pie Chart) ne doit être utilisé que pour montrer les parts d'un tout (et avec peu de catégories !). Utiliser le mauvais graphique peut induire en erreur et conduire à de mauvaises décisions stratégiques.", 
        example: "Evolution temporelle = Line Chart ; Comparaison = Bar Chart." 
      },
      { 
        heading: "Temps Réel vs Batch", 
        content: "Un dashboard peut être mis à jour de deux façons. En 'Batch', les données sont traitées par lots (ex: toutes les nuits). C'est économique et suffisant pour les rapports financiers. En 'Temps Réel' (Streaming), la donnée s'affiche dès qu'elle arrive. C'est vital pour surveiller la santé d'un serveur ou les cours de la bourse. Le choix dépend du coût que vous êtes prêt à payer pour la fraîcheur de l'information.", 
        example: "Batch = Rapport mensuel ; Streaming = Console de monitoring." 
      }
    ],
    quiz: [
      { question: "Quel graphique utiliser pour l'évolution du CA sur 10 ans ?", options: ["Pie Chart", "Line Chart", "G Nu Plot", "Scatter Plot"], correctIndex: 1 },
      { question: "L'objectif d'un dashboard est d'être compris en :", options: ["10 secondes", "2 heures", "1 jour", "5 minutes"], correctIndex: 0 },
      { question: "Une mise à jour 'Batch' signifie :", options: ["Instantanée", "Par lots différés", "À chaque clic", "Manuelle"], correctIndex: 1 },
      { question: "Le Pie Chart est déconseillé si :", options: ["Il y a trop de catégories", "Couleurs sombres", "Données fausses", "Pluie"], correctIndex: 0 },
      { question: "La DataViz sert principalement à :", options: ["Coder plus vite", "Cacher les erreurs", "Rendre la donnée visuelle et exploitable", "Vendre des serveurs"], correctIndex: 2 }
    ]
  },
  "Transactions (ACID) et Synthèse": {
    title: "Transactions et Fiabilité Ultime",
    sections: [
      { 
        heading: "Qu'est-ce qu'une Transaction ?", 
        content: "Une transaction est une unité de travail logique qui regroupe plusieurs opérations SQL. La règle est simple : Tout doit réussir, ou RIEN ne doit être appliqué. Si vous transférez 100€ d'un compte A vers un compte B, vous ne voulez pas que le débit réussisse mais que le crédit échoue à cause d'un crash. La transaction garantit que si une erreur survient, la base revient à son état initial exact (Rollback). C'est le fondement de la confiance numérique.", 
        example: "Mots-clés : BEGIN, COMMIT (valider), ROLLBACK (annuler)." 
      },
      { 
        heading: "Le Serment ACID", 
        content: "Pour être fiable, une base doit respecter l'acronyme ACID. A pour Atomique (tout ou rien). C pour Cohérent (respect des règles). I pour Isolé (les transactions ne se gênent pas). D pour Durable (une fois validé, c'est gravé sur le disque pour toujours, même après un crash). Ce sont les quatre piliers qui font qu'une base de données est digne de confiance pour gérer l'argent de millions de personnes ou des vies humaines.", 
        example: "Le protocole ACID est la norme d'or des banques." 
      },
      { 
        heading: "Synthèse : Vous êtes Expert", 
        content: "Félicitations ! Vous avez traversé toute la chaîne de valeur de la donnée. De la compréhension du besoin métier (MCD) à la mise en place physique (MPD), jusqu'à l'extraction de valeur par les KPIs et la sécurisation par les transactions. Vous avez maintenant les bases pour concevoir des systèmes de données solides, performants et fiables. Robin est fier de vous, l'Académie des données vous ouvre ses portes pour vos futurs projets !", 
        example: "Objectif atteint : Ingénieur de données certifié." 
      }
    ],
    quiz: [
      { question: "Que signifie le 'A' dans l'acronyme ACID ?", options: ["Application", "Automatique", "Atomique (Tout ou rien)", "Accessibilité"], correctIndex: 2 },
      { question: "Quelle commande annule une transaction en cours ?", options: ["CANCEL", "DELETE", "UNDO", "ROLLBACK"], correctIndex: 3 },
      { question: "Une transaction 'Durable' signifie :", options: ["Longue", "Survit aux pannes après validation", "Fixe", "Gratuite"], correctIndex: 1 },
      { question: "Pour enregistrer une transaction, on fait :", options: ["COMMIT", "SAVE", "EXIT", "VALIDATE"], correctIndex: 0 },
      { question: "Le 'I' de ACID (Isolation) garantit que :", options: ["Base seule", "Code secret", "Transactions concurrentes isolées", "Déconnecté"], correctIndex: 2 }
    ]
  }
};

export async function fetchLessonForTopic(topic: string): Promise<LessonContent> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `Génère un cours de base de données ultra-détaillé et académique pour le module : "${topic}".
  Chaque section doit impérativement contenir au moins 4-5 phrases riches en explications techniques et conceptuelles.
  Génère 5 questions de quiz de niveau ingénieur.
  IMPORTANT : Mélange parfaitement les réponses correctes (correctIndex). Distribue les bonnes réponses aléatoirement entre 0, 1, 2 et 3. Ne mets pas tout sur B.
  Format de réponse : JSON pur respectant le schéma suivant.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            sections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  heading: { type: Type.STRING },
                  content: { type: Type.STRING },
                  example: { type: Type.STRING }
                },
                required: ["heading", "content"]
              }
            },
            quiz: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctIndex: { type: Type.NUMBER }
                },
                required: ["question", "options", "correctIndex"]
              }
            }
          },
          required: ["title", "sections", "quiz"]
        }
      }
    });

    const data = JSON.parse(response.text) as LessonContent;
    if (!data.quiz || data.quiz.length < 5) throw new Error("Quiz trop court");
    return data;
  } catch (error) {
    console.warn(`Fallback riche spécifique activé pour : ${topic}`);
    return FALLBACK_LESSONS[topic] || FALLBACK_LESSONS["Introduction aux Bases de Données"];
  }
}
